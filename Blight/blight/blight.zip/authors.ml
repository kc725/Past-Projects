(* TODO: set the value below *)
let hours_worked = [30; 30; 20; 60]